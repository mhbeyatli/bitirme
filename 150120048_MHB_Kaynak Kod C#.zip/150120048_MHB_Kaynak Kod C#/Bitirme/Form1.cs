﻿/* İTÜ Bahar 2018
 BLG492 - Bİtirme Projesi
 Muhammed Habib Beyatlı - 150120048
 
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Bitirme
{
    public partial class Form1 : Form
    {
       

        public class insan
        {
            private int _id = 0;
            private int _aitoldugukat = 0;
            private int _bulundugukat = 0;
            private bool _harekethalinde = false;
            public double _hareketfrekans = 0;

            public insan(int id, int aok, int bk, double hf)
            {
                this._id = id;
                this._aitoldugukat = aok;
                this._bulundugukat = bk;
                this._hareketfrekans = hf;
            }

            public int idget()
            {
                return _id;
            }

            public void bulundugukatset(int a)
            {
                this._bulundugukat = a;
            }

            public int bulundugukatget()
            {
                return _bulundugukat;
            }

            public int aitoldugukatget()
            {
                return _aitoldugukat;
            }

            public void aitoldugukatset(int a)
            {
                this._aitoldugukat = a;
            }

            public void hareketfrekansset(int a)
            {
                this._hareketfrekans = a / 10000.0;
            }

            public bool harekethalindeget()
            {
                return _harekethalinde;
            }

            public void triggerharekethalinde()
            {
                if (_harekethalinde == false)
                    _harekethalinde = true;
                else if (_harekethalinde == true)
                    _harekethalinde = false;
            }
        }

        public class asansor
        {
            private int _id;
            private int _bulundugukat;
            private int _topsuzkosu;
            private uint _katgecissayaci;
            public List<transaction> islemler = new List<transaction>();
           

            public asansor(int id, int bk)
            {
                this._id = id;
                this._bulundugukat = bk;
                this._katgecissayaci = 0;
                this._topsuzkosu = -1;
            }

            public int idget()
            {
                return _id;
            }

            public void idset(int a)
            {
                this._id = a;
            }

            public int bulundugukatget()
            {
                return _bulundugukat;
            }

            public void bulundugukatset(int a)
            {
                this._bulundugukat = a;
            }

            public uint katgecissayaciget()
            {
                return _katgecissayaci;
            }
            
            public void katgecissayaciarttir()
            {
                this._katgecissayaci++;
            }

            public void katgecissayaciset(int a)
            {
                this._katgecissayaci = 0;
            }

            public int topsuzkosuget()
            {
                return _topsuzkosu;
            }

            public void topsuzkosuset(int a)
            {
                this._topsuzkosu = a;
            }

            public void transactionekle(int kid, int bk, int gik, int gun, int saa, int dak, int san)
            {
                transaction newt = new transaction(kid,bk,gik,gun,saa,dak,san);
                islemler[islemler.Count] = newt;
            }
        }

        public class transaction
        {
            private int _kisiid;
            private int _bulundugukat;
            private int _gitmekistedigikat;
            private int _gun;
            private int _saat;
            private int _dakika;
            private int _saniye;
          
            public transaction(int kid, int bk, int gik, int saa,int dak, int san)
            {
                this._kisiid = kid;
                this._bulundugukat = bk;
                this._gitmekistedigikat = gik;
                this._saat = saa;
                this._dakika = dak;
                this._saniye = san;
                this._gun = 0;
            }

            public transaction(int kid, int bk, int gik, int gun, int saa, int dak, int san)
            {
                this._kisiid = kid;
                this._bulundugukat = bk;
                this._gitmekistedigikat = gik;
                this._gun = gun;
                this._saat = saa;
                this._dakika = dak;
                this._saniye = san;
            }

            public int kisiidget()
            {
                return _kisiid;
            }

            public void kisiidset(int a)
            {
                this._kisiid = a;
            }

            public int bulundugukatget()
            {
                return _bulundugukat;
            }

            public void bulundugukatset(int a)
            {
                this._bulundugukat = a;
            }

            public int gitmekistedigikatget()
            {
                return _gitmekistedigikat;
            }

            public void gitmekistedigikatset(int a)
            {
                this._gitmekistedigikat = a;
            }

            public int gunget()
            {
                return _gun;
            }

            public int saatget()
            {
                return _saat;
            }

            public int dakikaget()
            {
                return _dakika;
            }

            public int saniyeget()
            {
                return _saniye;
            }
          
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random r = new Random();

            richTextBox1.Text = "";
            richTextBox2.Text = "";
            richTextBox4.Text = "";

             int insansayisi = hScrollBar1.Value; //Binada toplam X tane çalışan 
             int katsayisi = hScrollBar2.Value; //Binada X tane kat var
             double range = 0.3; //Binadaki insanlar katlara ortalamanın -X ve +X i açıklığında serpiştirildi
             int toplam = 0; //Kodlama için gereken anlamsız bir değer
             int otoparkartigiris = 5; //Binanın ilk X katı Otopark ve Zemin kat 
             int kackisiyeyemekhane = 100; // X kişi başına 1 yemekhane düşüyor
             int asansorsayisi = hScrollBar3.Value;
             int sistemuzunlugu = hScrollBar4.Value;

              int[] kat = new int[katsayisi];
              insan[] kitle = new insan[insansayisi];

              for (int i = 0; i < insansayisi; i++ )
              {
                  kitle[i] = new insan(i, 0, r.Next(0, otoparkartigiris-1), 0);
              }

              //asansor[] asansorler = new asansor[asansorsayisi];

              List<asansor> asansorler = new List<asansor>();

              for (int i = 0; i < asansorsayisi; i++)
              {                       
                  asansorler.Add(new asansor(i, r.Next(5,katsayisi)));
              
              }

              

              //transaction[] talepler = new transaction[5000];
              List<transaction> talepler = new List<transaction>();
              List<transaction> yedektalepler = new List<transaction>();
              List<transaction> algoritmatalepler = new List<transaction>();

                  while (true)
                  {
                      toplam = 0;
                      for (int i = otoparkartigiris; i < katsayisi; i++)
                      {
                          kat[i] = r.Next(Convert.ToInt32(Math.Floor((insansayisi / (katsayisi - otoparkartigiris)) * (1 - range))), Convert.ToInt32(Math.Floor((insansayisi / (katsayisi - otoparkartigiris)) * (1 + range))));
                          toplam = toplam + kat[i];            
                      }


                      if (toplam <= insansayisi && (toplam >= (insansayisi - (insansayisi * 0.02))))
                      {
                          //MessageBox.Show("Out 1");

                          toplam = insansayisi - toplam;

                          for (int i = 0; i < toplam; i++)
                          {

                              int temp = r.Next(0, katsayisi);
                              if (temp > otoparkartigiris - 1)
                              {
                                  kat[temp]++;
                              }
                              else
                              {
                                  i--;
                              }
                          }

                          break;
                      }
                     
                  }

         
              int insansayisiyedek = 0;

              for (int i = 0; i < katsayisi; i++)
              {
                  for (int j = 0; j < kat[i]; j++)
                  {
                    kitle[insansayisiyedek + j].aitoldugukatset(i);
                    kitle[insansayisiyedek + j].hareketfrekansset(Convert.ToInt32(r.Next(1, 6)));
                  }

                  insansayisiyedek += kat[i];
               
              }

              StreamWriter sw = new StreamWriter("islemler.txt");
              
             int yenigitmekistedigikat;
             int enyakinasansor;

            int[,] gecmisdata  = new int [30,44];
            int[,] toplamtransaction = new int[30,44];
            
            for(int i = 0 ; i < 30 ; i++)
            {
                for(int j = 0; j < 44 ; j++)
                {
                    gecmisdata[i,j] = 0;
                    toplamtransaction[i,j] = 0;
                }
            }



            //for (int gun = 0; gun < sistemuzunlugu; gun++)
            for(int gun = 0 ; gun < 30 ; gun++)
            {
                for (int saat = 8; saat < 19; saat++ )
                {
                    for(int dakika = 0; dakika < 60; dakika++)
                    {
                        for (int saniye = 0; saniye < 60;saniye++ )
                        { 
                            for (int i = 0; i < insansayisi; i++)
                            {

                                if (kitle[i].harekethalindeget())
                                {
                                    continue;
                                }

                                if(saat == 8 && kitle[i].bulundugukatget() != kitle[i].aitoldugukatget())
                                {
                                    if(1 > r.Next(0,3000))
                                    {
                                        talepler.Add(new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), kitle[i].aitoldugukatget(), gun, saat, dakika, saniye));
                                        kitle[i].triggerharekethalinde();
                                        sw.WriteLine(kitle[i].idget() + " No'lu çalışan : " + kitle[i].bulundugukatget() + " -> " + kitle[i].aitoldugukatget() + "   Saat:" + saat + ":" + dakika + "\tİşe Giriş");

                                        if (dakika < 15)
                                        {
                                            gecmisdata[gun, (saat - 8) * 4] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4]++;
                                        }

                                        else if (dakika < 30)
                                        {
                                            gecmisdata[gun, (saat - 8) * 4 + 1] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4 + 1]++;
                                        }

                                        else if (dakika < 45)
                                        {
                                            gecmisdata[gun, (saat - 8) * 4 + 2] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4 + 2]++;
                                        }

                                        else
                                        {
                                            gecmisdata[gun, (saat - 8) * 4 + 3] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4 + 3]++;
                                        }
                                    }

                                }

                                else if (saat == 18 && kitle[i].bulundugukatget() > 4)
                                {
                                    if (1 > r.Next(0, 2400))
                                    {
                                        int k = r.Next(0, otoparkartigiris);
                                        talepler.Add(new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), k, gun, saat, dakika, saniye));
                                        kitle[i].triggerharekethalinde();
                                        sw.WriteLine(kitle[i].idget() + " No'lu çalışan : " + kitle[i].bulundugukatget() + " -> " + k + "   Saat:" + saat + ":" + dakika + "\tİşten Çıkış");

                                        if (dakika < 15)
                                        {
                                            gecmisdata[gun, (saat - 8) * 4] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4]++;
                                        }

                                        else if (dakika < 30)
                                        {
                                            gecmisdata[gun, (saat - 8) * 4 + 1] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4 + 1]++;
                                        }

                                        else if (dakika < 45)
                                        {
                                            gecmisdata[gun, (saat - 8) * 4 + 2] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4 + 2]++;
                                        }

                                        else
                                        {
                                            gecmisdata[gun, (saat - 8) * 4 + 3] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4 + 3]++;
                                        }
                                    }
                                }

                                else if (kitle[i].aitoldugukatget() == kitle[i].bulundugukatget() && saat != 18)
                                {
                                    if ((kitle[i]._hareketfrekans)*10 > r.Next(0, 14400))
                                    {
                                        
                                        yenigitmekistedigikat = kitle[i].bulundugukatget();


                                        while (yenigitmekistedigikat == kitle[i].bulundugukatget())
                                        {
                                            yenigitmekistedigikat = r.Next(otoparkartigiris, katsayisi);
                                        }

                                        //talepler[talepler.Length] = new transaction(kitle[i].idget(), kitle[i].bulundugukatget() , yenigitmekistedigikat);
                                        talepler.Add(new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), yenigitmekistedigikat,gun, saat,dakika,saniye));
                                        kitle[i].triggerharekethalinde();
                                        
                                        sw.WriteLine(kitle[i].idget() + " No'lu çalışan : " + kitle[i].bulundugukatget() + " -> " + yenigitmekistedigikat + "   Saat:" + saat + ":" + dakika + "\tAit==>Başka");
                                      //  kitle[i].bulundugukatset(yenigitmekistedigikat);

                                        if (dakika < 15)
                                        {
                                            gecmisdata[gun, (saat - 8) * 4] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4]++;
                                        }

                                        else if (dakika < 30)
                                        {
                                            gecmisdata[gun, (saat - 8) * 4 + 1] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4 + 1]++;
                                        }

                                        else if (dakika < 45)
                                        {
                                            gecmisdata[gun, (saat - 8) * 4 + 2] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4 + 2]++;
                                        }

                                        else
                                        {
                                            gecmisdata[gun, (saat - 8) * 4 + 3] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4 + 3]++;
                                        }

                                    }
                                }

                                else if (r.Next(0, 2400) < kitle[i]._hareketfrekans && saat != 18)
                                {
                                    if (r.Next(0, 100) > 70)
                                    {
                                        yenigitmekistedigikat = kitle[i].bulundugukatget();

                                        while (yenigitmekistedigikat == kitle[i].bulundugukatget())
                                        {
                                            yenigitmekistedigikat = r.Next(otoparkartigiris, katsayisi);
                                        }
                                      
                                        
                                        //talepler[talepler.Length] = new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), yenigitmekistedigikat);
                                        talepler.Add(new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), yenigitmekistedigikat,gun, saat,dakika,saniye));
                                        kitle[i].triggerharekethalinde();
                                        
                                        sw.WriteLine(kitle[i].idget() + " No'lu çalışan : " + kitle[i].bulundugukatget() + " -> " + yenigitmekistedigikat + "   Saat:" + saat + ":" + dakika + "\tBaşka==>Başka");
                                      //  kitle[i].bulundugukatset(yenigitmekistedigikat);

                                        if (dakika < 15)
                                        {
                                            gecmisdata[gun, (saat - 8) * 4] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4]++;
                                        }

                                        else if (dakika < 30)
                                        {
                                            gecmisdata[gun, (saat - 8) * 4 + 1] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4 + 1]++;
                                        }

                                        else if (dakika < 45)
                                        {
                                            gecmisdata[gun, (saat - 8) * 4 + 2] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4 + 2]++;
                                        }

                                        else
                                        {
                                            gecmisdata[gun, (saat - 8) * 4 + 3] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4 + 3]++;
                                        }
                                    }

                                    else
                                    {
                                        yenigitmekistedigikat = kitle[i].aitoldugukatget();
                                        
                                        
                                        //talepler[talepler.Length]  = new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), yenigitmekistedigikat);
                                        talepler.Add(new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), yenigitmekistedigikat,gun, saat, dakika, saniye));
                                        kitle[i].triggerharekethalinde();
                                        
                                        sw.WriteLine(kitle[i].idget() + " No'lu çalışan : " + kitle[i].bulundugukatget() + " -> " + yenigitmekistedigikat + "   Saat:" + saat + ":" + dakika + "\tBaşka==>Ait");
                                      //  kitle[i].bulundugukatset(yenigitmekistedigikat);
                                        if (dakika < 15)
                                        {
                                            gecmisdata[gun, (saat - 8) * 4] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4]++;
                                        }

                                        else if (dakika < 30)
                                        {
                                            gecmisdata[gun, (saat - 8) * 4 + 1] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4 + 1]++;
                                        }

                                        else if (dakika < 45)
                                        {
                                            gecmisdata[gun, (saat - 8) * 4 + 2] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4 + 2]++;
                                        }

                                        else
                                        {
                                            gecmisdata[gun, (saat - 8) * 4 + 3] += kitle[i].bulundugukatget();
                                            toplamtransaction[gun, (saat - 8) * 4 + 3]++;
                                        }
                                      
                                    }
                                }
                            }

                            /*Asansör*/
                            
                           

                            for (int i = 0; i < talepler.Count; i++ )
                            {

                                enyakinasansor = -1;

                                for (int j = 0; j < asansorsayisi; j++)
                                {
                                    //Kabin dolu mu
                                    if (asansorler[j].islemler.Count == 10)
                                    {
                                        continue;
                                    }

                                    //Kabin yukarı mı gidiyor
                                    else if (asansorler[j].islemler.Count != 0 && (asansorler[j].islemler[0].gitmekistedigikatget() > asansorler[j].bulundugukatget() && talepler[i].bulundugukatget() < talepler[i].gitmekistedigikatget() && kitle[talepler[i].kisiidget()].bulundugukatget() > asansorler[j].bulundugukatget()))
                                    {

                                        if(enyakinasansor == -1)
                                        {
                                            enyakinasansor = j;
                                        }

                                       
                                        else if (talepler[i].bulundugukatget() - asansorler[j].bulundugukatget() < talepler[i].bulundugukatget() - asansorler[enyakinasansor].bulundugukatget())
                                        {
                                            enyakinasansor = j;
                                            //MessageBox.Show("Yukarı kat adam aldı");
                                        }
                                                                               
                                    }
                                    
                                    //Kabin aşağı mı gidiyor
                                    else if (asansorler[j].islemler.Count != 0 && (asansorler[j].islemler[0].gitmekistedigikatget() < asansorler[j].bulundugukatget() && talepler[i].bulundugukatget() > talepler[i].gitmekistedigikatget() && kitle[talepler[i].kisiidget()].bulundugukatget() < asansorler[j].bulundugukatget()))
                                    {
                                        
                                        if (enyakinasansor == -1)
                                        {
                                            enyakinasansor = j;
                                        }
                                        
                                        else if (talepler[i].bulundugukatget() - asansorler[j].bulundugukatget() > talepler[i].bulundugukatget() - asansorler[enyakinasansor].bulundugukatget())
                                        {
                                            enyakinasansor = j;
                                            
                                        }
                                    }

                                    //Kabin boş
                                    else if(asansorler[j].islemler.Count == 0)
                                    {
                                        if (enyakinasansor == -1)
                                        {
                                            enyakinasansor = j;
                                        }
                                        else if (talepler[i].bulundugukatget() - asansorler[j].bulundugukatget() > talepler[i].bulundugukatget() - asansorler[enyakinasansor].bulundugukatget())
                                        {
                                            enyakinasansor = j;

                                        }
                                    }
                                }

                                if(enyakinasansor != -1)
                                {
                                    //asansorler[enyakinasansor].islemler[asansorler[enyakinasansor].islemler.Count] = talepler[i];

                                    asansorler[enyakinasansor].islemler.Add(talepler[i]);
                                    
                                    if(asansorler[enyakinasansor].bulundugukatget() < asansorler[enyakinasansor].islemler[0].bulundugukatget())
                                    {
                                        asansorler[enyakinasansor].islemler.Sort((k1, k2) => k1.bulundugukatget().CompareTo(k2.bulundugukatget())); 
                                    }

                                    if (asansorler[enyakinasansor].bulundugukatget() > asansorler[enyakinasansor].islemler[0].bulundugukatget())
                                    {
                                        asansorler[enyakinasansor].islemler.Sort((k2, k1) => k1.bulundugukatget().CompareTo(k2.bulundugukatget())); 
                                    }
                                    
                                    talepler.RemoveAt(i);

                                    i--;
                                }
                            }

                            for(int i = 0 ; i < asansorsayisi ; i++ )
                            {
                                if(asansorler[i].islemler.Count > 0)
                                {

                                    if(asansorler[i].katgecissayaciget() % 5 == 0)
                                    {
                                        if(asansorler[i].islemler[0].gitmekistedigikatget() > asansorler[i].bulundugukatget())
                                        {
                                            asansorler[i].bulundugukatset(asansorler[i].bulundugukatget() + 1);  
                                        }
                                        if (asansorler[i].islemler[0].gitmekistedigikatget() < asansorler[i].bulundugukatget())
                                        {
                                            asansorler[i].bulundugukatset(asansorler[i].bulundugukatget() - 1);
                                        }
                                    }

                                    for(int j = 0; j < asansorler[i].islemler.Count ; j++ )
                                    {
                                        if(asansorler[i].islemler[j].gitmekistedigikatget() == asansorler[i].bulundugukatget())
                                        {
                                            kitle[asansorler[i].islemler[j].kisiidget()].bulundugukatset(asansorler[i].islemler[j].gitmekistedigikatget());
                                            kitle[asansorler[i].islemler[j].kisiidget()].triggerharekethalinde();

                                            asansorler[i].islemler.RemoveAt(j);
                                            j--;
                                        }

                                        else
                                        {
                                            break;
                                        }
                                    }

                                    asansorler[i].katgecissayaciarttir();
                                }
                            }


                        }
                    }
                }
               
            }
              

       
             uint toplamsure = 0;
             for (int z = 0; z < asansorsayisi; z++)
             {
                 toplamsure += asansorler[z].katgecissayaciget();
             }

             for (int z = 0; z < asansorsayisi; z++)
             {
                   richTextBox1.AppendText(z + 1 + ". asansör toplam hareket => " + asansorler[z].katgecissayaciget() / 3600 + " saat " + (asansorler[z].katgecissayaciget() % 3600 / 60) + " dakika " + asansorler[z].katgecissayaciget() % 60 + " saniye" + "\n");
             }


             richTextBox1.AppendText("Ortalama 1 asansörün çalıştığı süre : " + (toplamsure / asansorsayisi) / 3600 + " saat " + ((toplamsure / asansorsayisi) % 3600 / 60) + " dakika " + (toplamsure / asansorsayisi) % 60 + " saniye");
             //MessageBox.Show("Asansörlerin toplam harcadığı süre " + (toplamsure) / 3600 + " saat " + ((toplamsure) % 3600 / 60) + " dakika " + (toplamsure) % 60 + " saniye");

            /*
             *
             *
             *
             *
             *
             *
             *
             *
             *
             *
             *
             *
             *
             */

             int toplambeklemesuresi = 0;
             talepler.Clear();

             for (int i = 0; i < asansorsayisi; i++ )
             {
                 asansorler[i].katgecissayaciset(0);
                 asansorler[i].islemler.Clear();
             }

             double[] gunlukverim = new double[sistemuzunlugu];

             for (int gun = 0; gun < sistemuzunlugu; gun++)
                 //for (int gun = 0; gun < 30; gun++)
                 {
                     for (int saat = 8; saat < 19; saat++)
                     {
                         for (int dakika = 0; dakika < 60; dakika++)
                         {
                             for (int saniye = 0; saniye < 60; saniye++)
                             {
                                 for (int i = 0; i < insansayisi; i++)
                                 {
                                     if (kitle[i].harekethalindeget())
                                     {
                                         continue;
                                     }

                                     if (saat == 8 && kitle[i].bulundugukatget() != kitle[i].aitoldugukatget())
                                     {
                                         if (1 > r.Next(0, 3000))
                                         {
                                             talepler.Add(new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), kitle[i].aitoldugukatget(), gun, saat, dakika, saniye));
                                             yedektalepler.Add(new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), kitle[i].aitoldugukatget(), gun, saat, dakika, saniye));
                                             kitle[i].triggerharekethalinde();
                                         }

                                     }

                                     else if(saat == 18 && kitle[i].bulundugukatget() > 4)
                                    {
                                        if (1 > r.Next(0, 2400))
                                        {
                                            int k = r.Next(0, otoparkartigiris);
                                            talepler.Add(new transaction(kitle[i].idget(), kitle[i].bulundugukatget(),k, gun, saat, dakika, saniye));
                                            yedektalepler.Add(new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), k, gun, saat, dakika, saniye));
                                            kitle[i].triggerharekethalinde();
                                        }
                                    }

                                     else if (kitle[i].aitoldugukatget() == kitle[i].bulundugukatget() && saat != 18)
                                     {
                                         if ((kitle[i]._hareketfrekans)*10  > r.Next(0, 14400))
                                         {

                                             yenigitmekistedigikat = kitle[i].bulundugukatget();


                                             while (yenigitmekistedigikat == kitle[i].bulundugukatget())
                                             {
                                                 yenigitmekistedigikat = r.Next(otoparkartigiris, katsayisi);
                                             }

                                             //talepler[talepler.Length] = new transaction(kitle[i].idget(), kitle[i].bulundugukatget() , yenigitmekistedigikat);
                                             talepler.Add(new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), yenigitmekistedigikat,gun, saat, dakika, saniye));
                                             yedektalepler.Add(new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), yenigitmekistedigikat, gun, saat, dakika, saniye));
                                             kitle[i].triggerharekethalinde();

                                            // sw.WriteLine(kitle[i].idget() + " No'lu çalışan : " + kitle[i].bulundugukatget() + " -> " + yenigitmekistedigikat + "   Saat:" + saat + ":" + dakika + "\tAit==>Başka");
                                             //  kitle[i].bulundugukatset(yenigitmekistedigikat
                                         }
                                     }

                                     else if (r.Next(0, 2400) < kitle[i]._hareketfrekans && saat != 18)
                                     {
                                         if (r.Next(0, 100) > 70)
                                         {
                                             yenigitmekistedigikat = kitle[i].bulundugukatget();

                                             while (yenigitmekistedigikat == kitle[i].bulundugukatget())
                                             {
                                                 yenigitmekistedigikat = r.Next(otoparkartigiris, katsayisi);
                                             }


                                             //talepler[talepler.Length] = new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), yenigitmekistedigikat);
                                             talepler.Add(new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), yenigitmekistedigikat,gun, saat, dakika, saniye));
                                             yedektalepler.Add(new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), yenigitmekistedigikat, gun, saat, dakika, saniye));
                                             kitle[i].triggerharekethalinde();

                                            // sw.WriteLine(kitle[i].idget() + " No'lu çalışan : " + kitle[i].bulundugukatget() + " -> " + yenigitmekistedigikat + "   Saat:" + saat + ":" + dakika + "\tBaşka==>Ait");
                                             //  kitle[i].bulundugukatset(yenigitmekistedigikat);
                                         }

                                         else
                                         {
                                             yenigitmekistedigikat = kitle[i].aitoldugukatget();


                                             //talepler[talepler.Length]  = new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), yenigitmekistedigikat);
                                             talepler.Add(new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), yenigitmekistedigikat,gun, saat, dakika, saniye));
                                             yedektalepler.Add(new transaction(kitle[i].idget(), kitle[i].bulundugukatget(), yenigitmekistedigikat, gun, saat, dakika, saniye));
                                             kitle[i].triggerharekethalinde();

                                            // sw.WriteLine(kitle[i].idget() + " No'lu çalışan : " + kitle[i].bulundugukatget() + " -> " + yenigitmekistedigikat + "   Saat:" + saat + ":" + dakika + "\tBaşka==>Başka");
                                             //  kitle[i].bulundugukatset(yenigitmekistedigikat);
                                         }
                                     }
                                 }

                                 /*Asansör*/

                              

                                 for (int i = 0; i < talepler.Count; i++)
                                 {

                                     enyakinasansor = -1;

                                     for (int j = 0; j < asansorsayisi; j++)
                                     {
                                         //Kabin dolu mu
                                         if (asansorler[j].islemler.Count == 10)
                                         {
                                             continue;
                                         }

                                         //Kabin yukarı mı gidiyor
                                         if (asansorler[j].islemler.Count != 0 && (asansorler[j].islemler[0].gitmekistedigikatget() > asansorler[j].bulundugukatget() && talepler[i].bulundugukatget() < talepler[i].gitmekistedigikatget() && kitle[talepler[i].kisiidget()].bulundugukatget() > asansorler[j].bulundugukatget()))
                                         {
                                             if (enyakinasansor == -1)
                                             {
                                                 enyakinasansor = j;
                                             }
                                             else if (talepler[i].bulundugukatget() - asansorler[j].bulundugukatget() < talepler[i].bulundugukatget() - asansorler[enyakinasansor].bulundugukatget())
                                             {
                                                 enyakinasansor = j;
                                                 //MessageBox.Show("Yukarı kat adam aldı");
                                             }

                                         }

                                         //Kabin aşağı mı gidiyor
                                         if (asansorler[j].islemler.Count != 0 && (asansorler[j].islemler[0].gitmekistedigikatget() < asansorler[j].bulundugukatget() && talepler[i].bulundugukatget() > talepler[i].gitmekistedigikatget() && kitle[talepler[i].kisiidget()].bulundugukatget() < asansorler[j].bulundugukatget()))
                                         {
                                             if (enyakinasansor == -1)
                                             {
                                                 enyakinasansor = j;
                                             }
                                             else if (talepler[i].bulundugukatget() - asansorler[j].bulundugukatget() > talepler[i].bulundugukatget() - asansorler[enyakinasansor].bulundugukatget())
                                             {
                                                 enyakinasansor = j;

                                             }
                                         }

                                         //Kabin boş
                                         if (asansorler[j].islemler.Count == 0)
                                         {
                                             if (enyakinasansor == -1)
                                             {
                                                 enyakinasansor = j;
                                             }
                                             else if (talepler[i].bulundugukatget() - asansorler[j].bulundugukatget() > talepler[i].bulundugukatget() - asansorler[enyakinasansor].bulundugukatget())
                                             {
                                                 enyakinasansor = j;

                                             }
                                         }
                                     }

                                     if (enyakinasansor != -1)
                                     {
                                         //asansorler[enyakinasansor].islemler[asansorler[enyakinasansor].islemler.Count] = talepler[i];

                                         asansorler[enyakinasansor].islemler.Add(talepler[i]);

                                         if (asansorler[enyakinasansor].bulundugukatget() < asansorler[enyakinasansor].islemler[0].bulundugukatget())
                                         {
                                             asansorler[enyakinasansor].islemler.Sort((k1, k2) => k1.bulundugukatget().CompareTo(k2.bulundugukatget()));
                                         }

                                         if (asansorler[enyakinasansor].bulundugukatget() > asansorler[enyakinasansor].islemler[0].bulundugukatget())
                                         {
                                             asansorler[enyakinasansor].islemler.Sort((k2, k1) => k1.bulundugukatget().CompareTo(k2.bulundugukatget()));
                                         }

                                         talepler.RemoveAt(i);

                                         i--;
                                     }
                                 }

                                 for (int i = 0; i < asansorsayisi; i++)
                                 {
                                     if (asansorler[i].islemler.Count > 0)
                                     {

                                         if (asansorler[i].katgecissayaciget() % 5 == 0)
                                         {
                                             if (asansorler[i].islemler[0].gitmekistedigikatget() > asansorler[i].bulundugukatget())
                                             {
                                                 asansorler[i].bulundugukatset(asansorler[i].bulundugukatget() + 1);
                                             }
                                             if (asansorler[i].islemler[0].gitmekistedigikatget() < asansorler[i].bulundugukatget())
                                             {
                                                 asansorler[i].bulundugukatset(asansorler[i].bulundugukatget() - 1);
                                             }
                                         }

                                         for (int j = 0; j < asansorler[i].islemler.Count; j++)
                                         {
                                             if (asansorler[i].islemler[j].gitmekistedigikatget() == asansorler[i].bulundugukatget())
                                             {
                                                 kitle[asansorler[i].islemler[j].kisiidget()].bulundugukatset(asansorler[i].islemler[j].gitmekistedigikatget());
                                                 kitle[asansorler[i].islemler[j].kisiidget()].triggerharekethalinde();

                                                 toplambeklemesuresi += ((gun - asansorler[i].islemler[j].gunget()) * 36000) + ((saat - asansorler[i].islemler[j].saatget()) * 3600) + ((dakika - asansorler[i].islemler[j].dakikaget()) * 60) + ((saniye - asansorler[i].islemler[j].saniyeget()));
                                                 gunlukverim[gun] += ((gun - asansorler[i].islemler[j].gunget()) * 36000) + ((saat - asansorler[i].islemler[j].saatget()) * 3600) + ((dakika - asansorler[i].islemler[j].dakikaget()) * 60) + ((saniye - asansorler[i].islemler[j].saniyeget()));
                                                 asansorler[i].islemler.RemoveAt(j);
                                                 j--;
                                             }

                                             else
                                             {
                                                 break;
                                             }
                                         }

                                         asansorler[i].katgecissayaciarttir();
                                     }
                                 }


                             }
                         }
                     }
                 }

             toplamsure = 0;
             for (int z = 0; z < asansorsayisi; z++)
             {
                 toplamsure += asansorler[z].katgecissayaciget();
             }
             toplamsure = toplamsure / 5;

             for (int z = 0; z < asansorsayisi; z++)
             {
                 richTextBox2.AppendText(z + 1 + ". asansör toplam hareket => " + asansorler[z].katgecissayaciget() / 3600 + " saat " + (asansorler[z].katgecissayaciget() % 3600 / 60) + " dakika " + asansorler[z].katgecissayaciget() % 60 + " saniye" + "\n");
             }

             //richTextBox2.AppendText("Ortalama 1 asansörün çalıştığı süre : " + (toplamsure / asansorsayisi) / 3600 + " saat " + ((toplamsure / asansorsayisi) % 3600 / 60) + " dakika " + (toplamsure / asansorsayisi) % 60 + " saniye");
             //MessageBox.Show("Asansörlerin toplam harcadığı süre " + (toplamsure) / 3600 + " saat " + ((toplamsure) % 3600 / 60) + " dakika " + (toplamsure) % 60 + " saniye");

             int toplamsureint = Convert.ToInt32(toplamsure);

             toplambeklemesuresi = toplambeklemesuresi - toplamsureint;
             
             int toplambeklemesuresibir = toplambeklemesuresi;

             label10.Text = (toplambeklemesuresi) / 3600 + " saat " + ((toplambeklemesuresi) % 3600 / 60) + " dakika " + (toplambeklemesuresi) % 60 + " saniye";

             talepler.Clear();
             sw.Close();
            /*Algoritmalı 2. 30 gün
             *
             *
             *
             *
             *
             *
             *
             *
             *
             *
             *
             *
             *
             *
             *
             */

             for (int i = 0; i < asansorsayisi; i++)
             {
                 asansorler[i].katgecissayaciset(0);
                 asansorler[i].islemler.Clear();
             }

             toplambeklemesuresi = 0;
             double gunlukverimmax = -100;
             double gunlukverimmin = 100;
             double algoritmagunlukverim = 0;

             talepler.Clear();
             algoritmatalepler.Clear();

             int agirliknoktasi;
             int geribeslemetoplam = 0;
             int[] gecmistoplamdata = new int[44];
             int[] gecmistoplamtransaction = new int[44];

             List<int> pozisyonlar = new List<int>();
             List<int> yedekpozisyonlar = new List<int>();
             //int[] pozisyonlar = new int[asansorsayisi];
             //MessageBox.Show("Merhaba1");

             for (int gun = 0; gun < sistemuzunlugu; gun++)
             //for(int gun = 0 ; gun < 30 ; gun++)
             {
                 algoritmatalepler.Clear();
                 algoritmagunlukverim = 0;


                 for (int saat = 8; saat < 19; saat++)
                 {
                     for (int dakika = 0; dakika < 60; dakika++)
                     {
                         for (int saniye = 0; saniye < 60; saniye++)
                         {
                             
                             for (int i = 0; i < yedektalepler.Count; i++)
                             {
                                 if (yedektalepler[i].gunget() == gun && yedektalepler[i].saatget() == saat  && yedektalepler[i].dakikaget() == dakika  && yedektalepler[i].saniyeget() == saniye)
                                 {
                                     algoritmatalepler.Add(new transaction(yedektalepler[i].kisiidget(), kitle[yedektalepler[i].kisiidget()].bulundugukatget(), yedektalepler[i].gitmekistedigikatget(), saat, dakika, saniye));
                                     yedektalepler.RemoveAt(i);
                                     //geribeslemetoplam += kitle[yedektalepler[i].kisiidget()].bulundugukatget();
                                     i--;
                                 }
                                 else
                                 {
                                     break;
                                 }
                             }

                             /*
                             if(dakika == 14)
                             {
                                 gecmistoplamdata[(saat - 8) * 4] = geribeslemetoplam;
                                 geribeslemetoplam = 0;
                             }
                             if(dakika == 29)
                             {
                                 gecmistoplamdata[((saat - 8) * 4) + 1] = geribeslemetoplam;
                                 geribeslemetoplam = 0;
                             }
                             if(dakika == 44)
                             {
                                 gecmistoplamdata[((saat - 8) * 4) + 2] = geribeslemetoplam;
                                 geribeslemetoplam = 0;
                             }
                             if(dakika == 59)
                             {
                                 gecmistoplamdata[((saat - 8) * 4) + 3] = geribeslemetoplam;
                                 geribeslemetoplam = 0;
                             }*/

                        
                             if ((dakika == 0 && saniye == 0) || (dakika == 30 && saniye == 0))
                             {
                                 for (int i = 0; i < 44; i++)
                                 {
                                     gecmistoplamdata[i] = 0;
                                     gecmistoplamtransaction[i] = 0;
                                 }
                                


                                 for (int i = 0; i < 44; i++)
                                 {
                                     for (int j = 0; j < 30; j++)
                                     {
                                         gecmistoplamdata[i] += gecmisdata[j, i];
                                         gecmistoplamtransaction[i] += toplamtransaction[j, i];
                                     }
                                 }

                              
                                 if (saat == 8 && dakika < 30)
                                 {
                                     agirliknoktasi = Convert.ToInt16(Math.Round(Convert.ToDouble((((gecmistoplamdata[0] + gecmistoplamdata[1] + gecmistoplamdata[2]) / (gecmistoplamtransaction[0] + gecmistoplamtransaction[1] + gecmistoplamtransaction[2])))  )));

                                 }
                                 else if (saat == 18 && dakika > 29)
                                 {
                                     agirliknoktasi = Convert.ToInt16(Math.Round(Convert.ToDouble((((gecmistoplamdata[41] + gecmistoplamdata[42] + gecmistoplamdata[43]) / (gecmistoplamtransaction[41] + gecmistoplamtransaction[42] + gecmistoplamtransaction[43])))  )));

                                 }
                                 else if (dakika > 29)
                                 {
                                     agirliknoktasi = Convert.ToInt16(Math.Round(Convert.ToDouble((((gecmistoplamdata[(saat - 8) * 4 + 1] + gecmistoplamdata[(saat - 8) * 4 + 2] + gecmistoplamdata[(saat - 8) * 4 + 3] + gecmistoplamdata[(saat - 8) * 4 + 4]) / (gecmistoplamtransaction[(saat - 8) * 4 + 1] + gecmistoplamtransaction[(saat - 8) * 4 + 2] + gecmistoplamtransaction[(saat - 8) * 4 + 3] + gecmistoplamtransaction[(saat - 8) * 4 + 4])))  )));

                                 }

                                 else
                                 {
                                     agirliknoktasi = Convert.ToInt16(Math.Round(Convert.ToDouble((((gecmistoplamdata[(saat - 8) * 4 - 1] + gecmistoplamdata[(saat - 8) * 4] + gecmistoplamdata[(saat - 8) * 4 + 1] + gecmistoplamdata[(saat - 8) * 4 + 2]) / (gecmistoplamtransaction[(saat - 8) * 4 - 1] + gecmistoplamtransaction[(saat - 8) * 4] + gecmistoplamtransaction[(saat - 8) * 4 + 1] + gecmistoplamtransaction[(saat - 8) * 4 + 2])))  )));

                                 }

                                 //richTextBox4.AppendText(agirliknoktasi + "\n");

                                 pozisyonlar.Clear();

                                 double step;  
                                  
                                 if (asansorsayisi % 2 == 0)
                                 {
                                     step = (Convert.ToDouble(agirliknoktasi - otoparkartigiris) / asansorsayisi) / 4;
                                                                         
                                     for (double i = 3 * step + otoparkartigiris; i < agirliknoktasi; i += 4 * step)
                                     {
                                         //sw.WriteLine(i + " 1\n");
                                         pozisyonlar.Add(Convert.ToInt16(Math.Round(i)));               
                                     }

                                     pozisyonlar.Reverse();
                                     step = (Convert.ToDouble(katsayisi - agirliknoktasi) / asansorsayisi) / 4;

                                     for(double i = agirliknoktasi + step; i < katsayisi; i += 4 * step)
                                     {
                                         //sw.WriteLine(i + " 2\n");
                                         pozisyonlar.Add(Convert.ToInt16(Math.Round(i)));
                                     }
                                     
                                 }

                                 if (asansorsayisi % 2 == 1)
                                 {

                                     step = (Convert.ToDouble(agirliknoktasi - otoparkartigiris / asansorsayisi)) / 4;

                                  

                                     for (double i = 2 * step + otoparkartigiris; i < agirliknoktasi; i += 4 * step)
                                     {
                                         pozisyonlar.Add(Convert.ToInt16(Math.Round(i)));            
                                     }

                                     pozisyonlar.Add(agirliknoktasi);
                                     pozisyonlar.Reverse();
                                     step = (Convert.ToDouble(katsayisi - agirliknoktasi) / asansorsayisi) / 4;

                                     for (double i = agirliknoktasi + 2 * step; i < katsayisi; i += 4 * step)
                                     {
                                         pozisyonlar.Add(Convert.ToInt16(Math.Round(i)));
                                     }
                                 }

                                 for (int i = 0; i < asansorsayisi; i++)
                                 {
                                     for (int j = i; j < asansorsayisi - 1; j++)
                                     {
                                         if (Math.Abs(pozisyonlar[j] - agirliknoktasi) > Math.Abs(pozisyonlar[j+1] - agirliknoktasi))
                                         {
                                             int temp = pozisyonlar.IndexOf(j);
                                             pozisyonlar[j] = pozisyonlar[j + 1];
                                             pozisyonlar[j + 1] = temp;

                                         }
                                     }
                                 }
                             }

                            

                                 /*
                              
                                  */
                                 yedekpozisyonlar.Clear();
                             yedekpozisyonlar = pozisyonlar;

                             for (int i = 0; i < algoritmatalepler.Count; i++)
                             {

                                 enyakinasansor = -1;

                                 for (int j = 0; j < asansorsayisi; j++)
                                 {
                                     //Kabin dolu mu
                                     if (asansorler[j].islemler.Count == 10)
                                     {
                                         continue;
                                     }

                                     //Kabin yukarı mı gidiyor
                                     if (asansorler[j].islemler.Count != 0 && (asansorler[j].islemler[0].gitmekistedigikatget() > asansorler[j].bulundugukatget() && algoritmatalepler[i].bulundugukatget() < algoritmatalepler[i].gitmekistedigikatget() && kitle[algoritmatalepler[i].kisiidget()].bulundugukatget() > asansorler[j].bulundugukatget()))
                                     {
                                         if (enyakinasansor == -1)
                                         {
                                             enyakinasansor = j;
                                         }
                                         else if (algoritmatalepler[i].bulundugukatget() - asansorler[j].bulundugukatget() < algoritmatalepler[i].bulundugukatget() - asansorler[enyakinasansor].bulundugukatget())
                                         {
                                             enyakinasansor = j;
                                           
                                         }

                                     }

                                     //Kabin aşağı mı gidiyor
                                     if (asansorler[j].islemler.Count != 0 && (asansorler[j].islemler[0].gitmekistedigikatget() < asansorler[j].bulundugukatget() && algoritmatalepler[i].bulundugukatget() > algoritmatalepler[i].gitmekistedigikatget() && kitle[algoritmatalepler[i].kisiidget()].bulundugukatget() < asansorler[j].bulundugukatget()))
                                     {
                                         if (enyakinasansor == -1)
                                         {
                                             enyakinasansor = j;
                                         }
                                         else if (algoritmatalepler[i].bulundugukatget() - asansorler[j].bulundugukatget() > algoritmatalepler[i].bulundugukatget() - asansorler[enyakinasansor].bulundugukatget())
                                         {
                                             enyakinasansor = j;

                                         }
                                     }

                                     //Kabin boş
                                     if (asansorler[j].islemler.Count == 0)
                                     {
                                         if (enyakinasansor == -1)
                                         {
                                             enyakinasansor = j;
                                             asansorler[j].topsuzkosuset(-1);
                                         }
                                         else if (algoritmatalepler[i].bulundugukatget() - asansorler[j].bulundugukatget() > algoritmatalepler[i].bulundugukatget() - asansorler[enyakinasansor].bulundugukatget())
                                         {
                                             enyakinasansor = j;
                                             asansorler[j].topsuzkosuset(-1);
                                         }
                                     }
                                 }

                                 if (enyakinasansor != -1)
                                 {
                                     //asansorler[enyakinasansor].islemler[asansorler[enyakinasansor].islemler.Count] = talepler[i];

                                     asansorler[enyakinasansor].islemler.Add(algoritmatalepler[i]);

                                     if (asansorler[enyakinasansor].bulundugukatget() < asansorler[enyakinasansor].islemler[0].bulundugukatget())
                                     {
                                         asansorler[enyakinasansor].islemler.Sort((k1, k2) => k1.bulundugukatget().CompareTo(k2.bulundugukatget()));
                                     }

                                     if (asansorler[enyakinasansor].bulundugukatget() > asansorler[enyakinasansor].islemler[0].bulundugukatget())
                                     {
                                         asansorler[enyakinasansor].islemler.Sort((k2, k1) => k1.bulundugukatget().CompareTo(k2.bulundugukatget()));
                                     }

                                     algoritmatalepler.RemoveAt(i);

                                     i--;
                                 }
                             }

                             for (int i = 0; i < asansorsayisi; i++)
                             {
                                 bool flag = false;

                                 if (asansorler[i].topsuzkosuget() == -1)
                                 {

                                     for (int j = 0; j < yedekpozisyonlar.Count; j++)
                                     {
                                         flag = false;

                                         for (int k = 0; k < asansorsayisi; k++)
                                         {
                                             if (i == k)
                                             {
                                                 continue;
                                             }
                                             if (asansorler[k].islemler.Count > 0 && Math.Abs(asansorler[k].islemler[asansorler[k].islemler.Count - 1].gitmekistedigikatget() - yedekpozisyonlar[j]) < Math.Abs(asansorler[i].bulundugukatget() - yedekpozisyonlar[j]))
                                             {
                                                 flag = true;
                                             }

                                             if (asansorler[k].topsuzkosuget() == -1 && Math.Abs(asansorler[k].bulundugukatget() - yedekpozisyonlar[j]) < Math.Abs(asansorler[i].bulundugukatget() - yedekpozisyonlar[j]))
                                             {
                                                 flag = true;
                                             }

                                             if (asansorler[k].topsuzkosuget() == yedekpozisyonlar[j])
                                             {
                                                 flag = true;
                                             }

                                         }

                                         if (flag == false)
                                         {
                                             asansorler[i].topsuzkosuset(j);
                                             break;
                                         }
                                     }
                                 }


                                 if (asansorler[i].islemler.Count > 0)
                                 {

                                     if (asansorler[i].katgecissayaciget() % 5 == 0)
                                     {
                                         if (asansorler[i].islemler[0].gitmekistedigikatget() > asansorler[i].bulundugukatget())
                                         {
                                             asansorler[i].bulundugukatset(asansorler[i].bulundugukatget() + 1);
                                         }
                                         if (asansorler[i].islemler[0].gitmekistedigikatget() < asansorler[i].bulundugukatget())
                                         {
                                             asansorler[i].bulundugukatset(asansorler[i].bulundugukatget() - 1);
                                         }
                                     }

                                     for (int j = 0; j < asansorler[i].islemler.Count; j++)
                                     {
                                         if (asansorler[i].islemler[j].gitmekistedigikatget() == asansorler[i].bulundugukatget())
                                         {
                                             kitle[asansorler[i].islemler[j].kisiidget()].bulundugukatset(asansorler[i].islemler[j].gitmekistedigikatget());
                                             kitle[asansorler[i].islemler[j].kisiidget()].triggerharekethalinde();

                                             toplambeklemesuresi += ((saat - asansorler[i].islemler[j].saatget()) * 3600) + ((dakika - asansorler[i].islemler[j].dakikaget()) * 60) + ((saniye - asansorler[i].islemler[j].saniyeget()));
                                             algoritmagunlukverim += ((saat - asansorler[i].islemler[j].saatget()) * 3600) + ((dakika - asansorler[i].islemler[j].dakikaget()) * 60) + ((saniye - asansorler[i].islemler[j].saniyeget()));
                                             asansorler[i].islemler.RemoveAt(j);
                                             j--;

                                             if(asansorler[i].islemler.Count == 0)
                                             {
                                                 asansorler[i].topsuzkosuset(-1);
                                             }
                                         }

                                         else
                                         {
                                             break;
                                         }
                                     }

                                     asansorler[i].katgecissayaciarttir();
                                 }

                                 
                                 if(asansorler[i].topsuzkosuget() != -1 && asansorler[i].topsuzkosuget() != asansorler[i].bulundugukatget())
                                 {
                                     if(asansorler[i].katgecissayaciget() % 5 == 0)
                                     {
                                         if(asansorler[i].topsuzkosuget() > asansorler[i].bulundugukatget())
                                         {
                                             asansorler[i].bulundugukatset(asansorler[i].bulundugukatget() + 1);
                                         }

                                         if (asansorler[i].topsuzkosuget() < asansorler[i].bulundugukatget())
                                         {
                                             asansorler[i].bulundugukatset(asansorler[i].bulundugukatget() - 1);
                                         }
                                     }

                                     asansorler[i].katgecissayaciarttir();
                                 }
                                 
                             }

                         }
                     }
                 }

                
                 
                 if(100 - ((algoritmagunlukverim / gunlukverim[gun]) *100 ) > gunlukverimmax)
                 {
                     gunlukverimmax = 100 - ((algoritmagunlukverim / gunlukverim[gun]) * 100); 
                 }

                 if (100 - ((algoritmagunlukverim / gunlukverim[gun]) * 100) < gunlukverimmin)
                 {
                     gunlukverimmin = 100 - ((algoritmagunlukverim / gunlukverim[gun]) * 100); 
                 }
            }

             toplamsure = 0;
             for (int z = 0; z < asansorsayisi; z++)
             {
                 toplamsure += asansorler[z].katgecissayaciget();
             }
             toplamsure = toplamsure / 5;

             toplamsureint = Convert.ToInt32(toplamsure);

             toplambeklemesuresi = toplambeklemesuresi - toplamsureint;

             label11.Text = (toplambeklemesuresi) / 3600 + " saat " + ((toplambeklemesuresi) % 3600 / 60) + " dakika " + (toplambeklemesuresi) % 60 + " saniye";

             for (int z = 0; z < asansorsayisi; z++)
             {
                 richTextBox4.AppendText(z + 1 + ". asansör toplam hareket => " + asansorler[z].katgecissayaciget() / 3600 + " saat " + (asansorler[z].katgecissayaciget() % 3600 / 60) + " dakika " + asansorler[z].katgecissayaciget() % 60 + " saniye" + "\n");
             }

            // richTextBox4.AppendText("Ortalama 1 asansörün çalıştığı süre : " + (toplamsure / asansorsayisi) / 3600 + " saat " + ((toplamsure / asansorsayisi) % 3600 / 60) + " dakika " + (toplamsure / asansorsayisi) % 60 + " saniye");
             
            if(sistemuzunlugu == 1)
            {
                MessageBox.Show("Minimum günlük verim : % " + Convert.ToString(100 - ((toplambeklemesuresi / toplambeklemesuresibir) * 100)) + "\nMaksimum günlük verim : % " + Convert.ToString(100 - ((toplambeklemesuresi / toplambeklemesuresibir) * 100)) + "\nVerim : % " + Convert.ToString(100 - ((toplambeklemesuresi / toplambeklemesuresibir) * 100)));
            }
            
            else if(sistemuzunlugu == 2)
            {
                 MessageBox.Show("Minimum günlük verim : % " + Convert.ToString(gunlukverimmin) + "\nMaksimum günlük verim : % " + Convert.ToString(gunlukverimmax) + "\nVerim : % " + Convert.ToString((gunlukverimmax + gunlukverimmin) / 2 ));
             
            }
            
            else
            { 
                 MessageBox.Show("Minimum günlük verim : % " + Convert.ToString(gunlukverimmin) + "\nMaksimum günlük verim : % " + Convert.ToString(gunlukverimmax) + "\nVerim : % " + Convert.ToString(100 - ((Convert.ToDouble(toplambeklemesuresi) / Convert.ToDouble(toplambeklemesuresibir)) * 100)));
            }
             
        }

        

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
           label1.Text = hScrollBar1.Value.ToString();
           label5.Text = (hScrollBar1.Value / (hScrollBar2.Value - 5)).ToString();
        }

        private void hScrollBar2_Scroll(object sender, ScrollEventArgs e)
        {
           label2.Text = hScrollBar2.Value.ToString();
           label5.Text = (hScrollBar1.Value / (hScrollBar2.Value - 5)).ToString();
        }

        private void hScrollBar3_Scroll(object sender, ScrollEventArgs e)
        {
            label7.Text = hScrollBar3.Value.ToString();
        }

        private void hScrollBar4_Scroll(object sender, ScrollEventArgs e)
        {
            label9.Text = hScrollBar4.Value.ToString();
        }



   
      

    }
}
